#include <stdio.h>
 
int main(void)
{
    hello();
    hello();
    return 0;
}
 
void hello()
{
    printf("Hello!\n");
}

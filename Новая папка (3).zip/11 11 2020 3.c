#include <stdio.h>
#define print(a) printf("%d \n", a)
 
int main(void)
{
    int x = 10;
    print(x);
    int y =20;
    print(y);
    print(22);
    return 0;
}

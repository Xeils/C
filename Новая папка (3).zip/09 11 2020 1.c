#define BEGIN {
#define END }
#define N 23
 
int main(void)
BEGIN
    int x = N;
    return 0;
END

#include <stdio.h>
#include "main.c"
 
int main(void)
{
    printf("%d", number);   // 5
    return 0;
}

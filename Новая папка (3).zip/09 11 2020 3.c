#include <stdio.h>
 
#define N 4
 
int main(void)
{
    char symbol = 'N';
    printf("%c \n", symbol);    // N
    printf("N");                //N
    return 0;
}

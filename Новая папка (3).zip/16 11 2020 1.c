#include <stdio.h>
 
void hello()
{
    printf("Hello!\n");
}
 
int main(void)
{   
    hello();
    hello();
    return 0;
}
